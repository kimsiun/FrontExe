document.write("새해마다 새로워집시다");

function greeting(){
  alert("안녕하세요");
}